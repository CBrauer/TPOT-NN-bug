import warnings
warnings.filterwarnings("ignore")
import platform
import sys
import pandas as pd
import numpy as np
import time
from IPython.core.display import HTML, display
pd.set_option('display.max_rows', 10)
pd.set_option('display.max_columns', 11)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)

import tpot
from tpot import TPOTClassifier

from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import accuracy_score
from sklearn.utils import shuffle

class Timer:
    def __init__(self):
        self.start = time.time()

    def restart(self):
        self.start = time.time()

    def get_time(self):
        end = time.time()
        m, s = divmod(end - self.start, 60)
        h, m = divmod(m, 60)
        time_str = "%02d:%02d:%02d" % (h, m, s)
        return time_str

def LoadData():

    df = pd.read_csv('rocket.csv')

    response_column = ['Altitude']
    feature_columns = ['BoxRatio', 'Thrust', 'Acceleration', 'Velocity', 'OnBalRun', 'vwapGain', 'Expect', 'Trin']
    header = feature_columns + response_column

    df_describe = df[feature_columns].describe(include='all')
    display(df_describe)
    
    X = df[feature_columns].values
    y = df[response_column].values.ravel()

    X_train, X_test, y_train, y_test = train_test_split(X,
                                                        y,
                                                        test_size = 0.2,
                                                        random_state = 7)
    print('Size of dataset:')
    print(' train shape... ', X_train.shape, y_train.shape)
    print(' test shape.... ', X_test.shape, y_test.shape)

    return X_train, y_train, X_test, y_test

def Main(g, p):
    X_train, y_train, X_test, y_test = LoadData()

    clf = TPOTClassifier(config_dict='TPOT NN',
                         template='Selector-Transformer-PytorchLRClassifier',
                         verbosity=2,
                         generations=g,
                         population_size=p,
                         random_state=7)
    clf.fit(X_train, y_train)
    print(clf.score(X_test, y_test))
    clf.export('tpot_nn_demo_pipeline.py')

if __name__ == "__main__":
  
    print('Operating system version....', platform.platform())
    print("Python version is........... %s.%s.%s" % sys.version_info[:3])
    print('pandas version is...........', pd.__version__)
    print('numpy version is............', np.__version__)
    print('tpot version is.............', tpot.__version__)

    my_timer = Timer()

    Main(10, 10)

    elapsed = my_timer.get_time()
    print("\nTotal compute time was: %s" % elapsed)

